# -*- coding: utf-8 -*-
"""
    𝔣𝔯𝔞𝔨𝔱𝔲𝔯
    ~~~~~~~
    𝔠𝔬𝔫𝔳𝔢𝔯𝔱 𝔱𝔥𝔢 𝔩𝔞𝔱𝔦𝔫 𝔞𝔩𝔭𝔥𝔞𝔟𝔢𝔱 𝔱𝔬 𝔣𝔯𝔞𝔨𝔱𝔲𝔯 𝔲𝔫𝔦𝔠𝔬𝔡𝔢 𝔠𝔥𝔞𝔯𝔞𝔠𝔱𝔢𝔯𝔰

    :license: 𝔐𝕴𝔗, 𝔰𝔢𝔢 𝔏𝕴𝕮𝔈𝔑𝔖𝔈 𝔣𝔬𝔯 𝔪𝔬𝔯𝔢 𝔡𝔢𝔱𝔞𝔦𝔩𝔰.
"""
from .fraktur import encode, decode

__version__ = '1.0.2'
__all__ = ['encode', 'decode']
